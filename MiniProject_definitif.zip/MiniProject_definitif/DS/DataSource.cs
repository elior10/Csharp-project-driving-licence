﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE;

namespace DS
{
    public class DataSource
    {
        public static List<Tester> list_tester = new List<Tester>();
        public static List<Trainee> list_trainee = new List<Trainee>();
        public static List<Test> list_test = new List<Test>();
    }
}
